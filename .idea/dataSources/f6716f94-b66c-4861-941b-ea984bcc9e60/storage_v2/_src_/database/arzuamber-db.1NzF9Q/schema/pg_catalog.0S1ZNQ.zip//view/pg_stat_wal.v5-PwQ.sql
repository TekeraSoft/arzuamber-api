create view pg_stat_wal
            (wal_records, wal_fpi, wal_bytes, wal_buffers_full, wal_write, wal_sync, wal_write_time, wal_sync_time,
             stats_reset) as
SELECT wal_records,
       wal_fpi,
       wal_bytes,
       wal_buffers_full,
       wal_write,
       wal_sync,
       wal_write_time,
       wal_sync_time,
       stats_reset
FROM pg_stat_get_wal() w(wal_records, wal_fpi, wal_bytes, wal_buffers_full, wal_write, wal_sync, wal_write_time,
                         wal_sync_time, stats_reset);

alter table pg_stat_wal
    owner to arzuamber_user;

grant select on pg_stat_wal to public;

